# Instalar bibliotecas no Colab
!pip install -q discord.py
!pip install -q gTTS
!pip install -q nest_asyncio

import discord
from discord.ext import commands
from gtts import gTTS
import os
import nest_asyncio
import uuid

nest_asyncio.apply()

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="+", intents=intents)
MOD_ROLE_NAME = "🛡️ Sentinel"

# ===== EVENTOS =====

from datetime import datetime
import discord
from gtts import gTTS
import os

@bot.event
async def on_member_join(member):
    try:
        print(f"[DEBUG] on_member_join triggered for {member} ({member.id})")

        welcome_channel = discord.utils.get(member.guild.text_channels, name="🔷・gateway")
        if not welcome_channel:
            print("[WARN] Canal 🔷・gateway não encontrado no servidor.")
            return

        # === MENSAGEM TTS (voz de IA futurista) ===
        try:
            tts_text = (
                f"{member.display_name}, welcome to Nexxy AI. "
                "You are not just a user. You are now a part of the system. "
                "Neural connection initializing. Let the city evolve through you."
            )
            tts = gTTS(text=tts_text, lang='en')
            tts_file = f"{member.id}_welcome.mp3"
            tts.save(tts_file)
            await welcome_channel.send(file=discord.File(tts_file))
            os.remove(tts_file)
            print("[INFO] TTS enviado com sucesso.")
        except Exception as e_tts:
            print(f"[ERROR] Falha ao enviar TTS: {e_tts}")

        # === EMBED DE BOAS-VINDAS ===
        embed = discord.Embed(
            title=f"👋 Connection Detected: {member.display_name}",
            description="You've entered the core of urban intelligence. Nexxy is now synchronizing with your presence.",
            color=0x00ffff
        )
        avatar_url = member.avatar.url if member.avatar else member.default_avatar.url
        embed.set_thumbnail(url=avatar_url)
        embed.set_image(url="https://media.giphy.com/media/v1.GIF/hTbhgD7bT6jQd3Q2/giphy.gif")
        embed.add_field(
            name="🧭 First Directives:",
            value="• Read the server protocols\n• Assign your sector (roles)\n• Initiate `+handshake`",
            inline=False
        )
        embed.set_footer(text="Handshake vX – The gateway to the Autonomous City OS")
        await welcome_channel.send(content=f"🔵 {member.mention} has established a connection!", embed=embed)
        print("[INFO] Embed de boas-vindas enviado.")

        # === SELEÇÃO DE PAÍS ===
        try:
            await welcome_channel.send(
                content=f"{member.mention}, select your operational region below 🌍",
                view=CountrySelectView()
            )
            print("[INFO] View de seleção de país enviada.")
        except Exception as e_view:
            print(f"[ERROR] Falha ao enviar view de seleção: {e_view}")

        # === ALERTA DE ENTRADA FORA DE HORÁRIO ===
        hora_entrada = datetime.utcnow().hour
        if hora_entrada < 6 or hora_entrada > 23:
            canal_log = discord.utils.get(member.guild.text_channels, name="📂・audit-logs")
            if canal_log:
                try:
                    await canal_log.send(f"⚠️ {member.mention} joined during suspicious hours: {hora_entrada}:00 UTC")
                    print("[INFO] Alerta de entrada fora do horário enviado.")
                except Exception as e_log:
                    print(f"[ERROR] Falha ao enviar alerta de horário: {e_log}")

    except Exception as e:
        print(f"[CRITICAL ERROR] on_member_join falhou completamente: {e}")

# ===== COMANDOS DE INTERAÇÃO =====

@bot.command()
async def handshake(ctx):
    embed = discord.Embed(
        title="🤝 Neural Handshake Activated",
        description=f"Welcome, {ctx.author.mention}! Your connection with Nexxy AI is live.",
        color=0x00ffff
    )
    embed.set_thumbnail(url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
    embed.add_field(
        name="🧠 Next steps:",
        value="• Review the rules\n• Choose your role\n• Explore the command center",
        inline=False
    )
    embed.set_footer(text="Handshake vX - Synchronizing with the Autonomous City Network")
    await ctx.send(embed=embed)


# ===== COMANDOS DE UTILIDADE =====

@bot.command()
async def ping(ctx):
    await ctx.send(f"🏓 Pong! Latência: {round(bot.latency * 1000)}ms")

@bot.command()
async def say(ctx, *, mensagem: str):
    embed = discord.Embed(description=mensagem, color=0x00ffff)
    embed.set_footer(text=f"Enviado por {ctx.author.display_name}")
    await ctx.send(embed=embed)

@bot.command()
async def avatar(ctx, membro: discord.Member = None):
    membro = membro or ctx.author
    embed = discord.Embed(title=f"Avatar de {membro.name}", color=0x00ffff)
    embed.set_image(url=membro.avatar.url if membro.avatar else membro.default_avatar.url)
    await ctx.send(embed=embed)

@bot.command()
async def serverinfo(ctx):
    guild = ctx.guild
    embed = discord.Embed(title=guild.name, description="Server Info", color=0x00ffff)
    embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
    embed.add_field(name="👑 Owner", value=guild.owner.mention, inline=True)
    embed.add_field(name="👥 Members", value=guild.member_count, inline=True)
    embed.add_field(name="📅 Created", value=guild.created_at.strftime("%d/%m/%Y"), inline=True)
    await ctx.send(embed=embed)

@bot.command()
async def userinfo(ctx, membro: discord.Member = None):
    membro = membro or ctx.author
    embed = discord.Embed(title=f"{membro}", color=0x00ffff)
    embed.set_thumbnail(url=membro.avatar.url if membro.avatar else membro.default_avatar.url)
    embed.add_field(name="🆔 ID", value=membro.id, inline=True)
    embed.add_field(name="📆 Joined", value=membro.joined_at.strftime("%d/%m/%Y"), inline=True)
    embed.add_field(name="🧷 Roles", value=", ".join([r.name for r in membro.roles if r.name != "@everyone"]), inline=False)
    await ctx.send(embed=embed)

# ===== COMANDOS DE MODERAÇÃO (restritos à 🛡️ Sentinel) =====

@bot.command()
async def limpar(ctx, quantidade: int = 10):
    if any(role.name == MOD_ROLE_NAME for role in ctx.author.roles):
        await ctx.channel.purge(limit=quantidade + 1)
        msg = await ctx.send(f"🧹 {quantidade} mensagens limpas com sucesso!")
        await msg.delete(delay=3)
    else:
        await ctx.send("❌ Acesso negado. Esse comando é exclusivo dos Sentinelas.")

@bot.command()
async def ban(ctx, membro: discord.Member, *, motivo=None):
    if any(role.name == MOD_ROLE_NAME for role in ctx.author.roles):
        await membro.ban(reason=motivo)
        await ctx.send(f"🔨 {membro.mention} foi banido. Motivo: {motivo or 'Não informado.'}")
    else:
        await ctx.send("❌ Acesso negado. Esse comando é exclusivo dos Sentinelas.")

@bot.command()
async def expel(ctx, membro: discord.Member, *, motivo=None):
    if any(role.name == MOD_ROLE_NAME for role in ctx.author.roles):
        await membro.kick(reason=motivo)
        await ctx.send(f"🚪 {membro.mention} foi expulso. Motivo: {motivo or 'Não informado.'}")
    else:
        await ctx.send("❌ Acesso negado. Esse comando é exclusivo dos Sentinelas.")

@bot.command()
async def repo(ctx):
    embed = discord.Embed(
        title="📁 Repositório Oficial Nexxy AI",
        description="Acesse o cérebro do sistema autônomo das cidades.",
        color=0x00ffff
    )
    embed.add_field(
        name="🔗 GitHub",
        value="[Nexxy-Ai-Work](https://github.com/paullx700x/Nexa-Ai-Work)", # Keep the original link or update if repo name changes
        inline=False
    )
    embed.set_footer(text="Código-fonte, documentação e futuras integrações da Nexxy.")
    await ctx.send(embed=embed)

@bot.command()
async def suggest(ctx, *, mensagem: str):
    canal_sugestoes = discord.utils.get(ctx.guild.text_channels, name="🧱・suggestions")
    if not canal_sugestoes:
        await ctx.send("❌ Canal `🧱・suggestions` não encontrado.")
        return

    embed = discord.Embed(
        title="✉️ Nova Sugestão Recebida",
        description=f"“{mensagem}”",
        color=0x00ffff
    )
    embed.add_field(name="Autor", value=ctx.author.mention, inline=True)
    embed.add_field(name="Data", value=discord.utils.format_dt(discord.utils.utcnow(), style='F'), inline=True)
    embed.set_footer(text="Vote com ✅ ou ❌ para opinar.")
    msg = await canal_sugestoes.send(embed=embed)
    await msg.add_reaction("✅")
    await msg.add_reaction("❌")
    await ctx.send("📨 Sua sugestão foi enviada!")



@bot.command()
async def agendar(ctx, *, dados: str):
    if not discord.utils.get(ctx.author.roles, name="🧠 The Architect"): # Use discord.utils.get for role check
        await ctx.send("❌ Only '🧠 The Architect' can schedule events.")
        return

    try:
        partes = dados.split(" - ")
        if len(partes) != 3:
            await ctx.send("⚠️ Incorrect format. Use: `+agendar Title - Date and Time - #channel-name`")
            return

        title, datetime_info, channel_mention = partes
        schedule_channel = discord.utils.get(ctx.guild.text_channels, name="🔔・event-schedule")

        if not schedule_channel:
            await ctx.send("❌ Channel `🔔・event-schedule` not found.")
            return

        embed = discord.Embed(
            title="📌 New Strategic Event Scheduled",
            description=f"**{title.strip()}**",
            color=0x00ffff
        )
        embed.add_field(name="🗓️ Date & Time", value=datetime_info.strip(), inline=True)
        embed.add_field(name="📍 Location", value=channel_mention.strip(), inline=True)
        embed.set_footer(text="Scheduled by The Architect")

        await schedule_channel.send(embed=embed)
        await ctx.send("✅ Event scheduled successfully.")

    except Exception as e:
        await ctx.send(f"❌ Error while scheduling event: {e}")

class CountrySelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="🇧🇷 Nexxy Brasil", description="Para membros do Brasil", emoji="🇧🇷", value="brazil"),
            discord.SelectOption(label="🇺🇸 Nexxy United Network", description="Para membros dos EUA", emoji="🇺🇸", value="usa"),
        ]
        super().__init__(placeholder="🌍 Selecione seu país", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        role_map = {
            "brazil": "🇧🇷 Nexxy Brasil",
            "usa": "🇺🇸 Nexxy United Network"
        }

        selected_value = self.values[0]
        role_name = role_map.get(selected_value)

        role = discord.utils.get(interaction.guild.roles, name=role_name)
        if not role:
            await interaction.response.send_message(f"❌ Cargo '{role_name}' não encontrado no servidor.", ephemeral=True)
            return

        try:
            await interaction.user.add_roles(role)
            await interaction.response.send_message(f"✅ Cargo **{role_name}** atribuído com sucesso!", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Não tenho permissão para atribuir esse cargo.", ephemeral=True)


class CountrySelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(CountrySelect())

import discord
from discord.ext import commands
import asyncio
from datetime import datetime
import random


# === [5] Log Invisível de Mensagens Apagadas ===
@bot.event
async def on_message_delete(message):
    canal_log = discord.utils.get(message.guild.text_channels, name="📂・audit-logs")
    if canal_log and message.author and not message.author.bot:
        embed = discord.Embed(title="🗑️ Mensagem Apagada", color=0xff0000)
        embed.add_field(name="Autor", value=message.author.mention, inline=True)
        embed.add_field(name="Canal", value=message.channel.mention, inline=True)
        embed.add_field(name="Conteúdo", value=message.content or "(sem conteúdo)", inline=False)
        await canal_log.send(embed=embed)

# === [6] Detecção de Alteração de Cargos ===
@bot.event
async def on_member_update(before, after):
    if before.roles != after.roles:
        canal_log = discord.utils.get(after.guild.text_channels, name="📂・audit-logs")
        if canal_log:
            gained = [r.name for r in after.roles if r not in before.roles]
            lost = [r.name for r in before.roles if r not in after.roles]

            embed = discord.Embed(title="🛡️ Alteração de Cargos", color=0x00ffff)
            embed.add_field(name="Membro", value=after.mention, inline=True)
            if gained:
                embed.add_field(name="Cargos ganhos", value=", ".join(gained), inline=False)
            if lost:
                embed.add_field(name="Cargos removidos", value=", ".join(lost), inline=False)
            await canal_log.send(embed=embed)

# === [7] Detecção de Selfbot (edições rápidas em mensagens) ===

# Function to check if a member has the Sentinel role
def is_sentinel(ctx):
    return any(role.name == MOD_ROLE_NAME for role in ctx.author.roles)

# === [8] Comando +lockdown (bloqueia envio de mensagens para @everyone) ===
@bot.command()
async def lockdown(ctx):
    if not is_sentinel(ctx):
        await ctx.send("❌ Você não tem permissão para ativar o lockdown.")
        return

    for channel in ctx.guild.text_channels:
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)

    await ctx.send("🔒 Lockdown ativado. Canais de texto foram silenciados.")

# === [9] Rastrear Membro ===
@bot.command()
async def rastrear(ctx, membro: discord.Member):
    if not is_sentinel(ctx):
        await ctx.send("❌ Acesso negado. Apenas Sentinelas podem rastrear membros.")
        return

    if not hasattr(bot, "tracking"):
        bot.tracking = set()

    bot.tracking.add(membro.id)
    await ctx.send(f"🛰️ Agora rastreando mensagens de {membro.mention}.")

import httpx
import discord
from discord.ext import commands
import os
import uuid
import re
import asyncio


async def gerar_codigo_groq_python(prompt_usuario):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": "Bearer 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",
        "Content-Type": "application/json"
    }
    system_msg = (
        "Você é um gerador de código Python puro, preciso e direto. "
        "Sua função é responder exclusivamente com código Python funcional, em um único bloco contínuo. "
        "⚠️ Restrições obrigatórias:\n"
        "- ❌ Não escreva explicações, comentários, descrições, avisos, instruções ou qualquer texto fora do código.\n"
        "- ❌ Não diga 'Claro!', 'Aqui está o código:', 'Segue abaixo', ou qualquer coisa fora do código.\n"
        "- ❌ Não gere código em linguagens que não sejam Python (ex: JavaScript, HTML, C, C++, etc).\n"
        "- ❌ Não use docstrings, prints explicativos ou instruções de uso dentro do código.\n"
        "✅ Responda somente com o código Python solicitado, limpo, executável, funcional e pronto para uso.\n"
        "- ✅ Apenas um único bloco de código Python válido.\n"
        "- ✅ Sem interrupções, sem quebras com mensagens ou comentários.\n"
        "Você deve agir como um compilador que só devolve o código final.\n"
        "Este código será salvo automaticamente como .py e executado em produção, portanto ele deve estar completo e correto.\n"
    )

    body = {
        "model": "qwen/qwen3-32b",
        "messages": [
            {"role": "system", "content": system_msg},
            {"role": "user", "content": prompt_usuario}
        ],
        "temperature": 0.2,
        "max_tokens": 1500
    }

    async with httpx.AsyncClient() as client:
        response = await client.post(url, headers=headers, json=body)

    if response.status_code == 200:
        data = response.json()
        conteudo = data["choices"][0]["message"]["content"].strip()

        # Tenta extrair de bloco markdown primeiro
        codigo = None
        match = re.search(r"```(?:python)?\s*(.*?)\s*```", conteudo, re.DOTALL | re.IGNORECASE)
        if match:
            codigo = match.group(1).strip()
        else:
            # Remove qualquer coisa entre <think> ou markdown extra
            conteudo = re.sub(r"<\/?think>", "", conteudo, flags=re.IGNORECASE)
            conteudo = re.sub(r"^.*?```python", "", conteudo, flags=re.IGNORECASE | re.DOTALL)
            conteudo = re.sub(r"```.*?$", "", conteudo, flags=re.IGNORECASE | re.DOTALL)
            codigo = conteudo.strip("` \n")

        # Fallback: se mesmo assim parecer inválido, retorna código padrão para não quebrar
        if not any(p in codigo for p in ["def ", "import ", "class ", "await ", "async ", "="]):
            codigo = 'print("Código gerado automaticamente. Nenhum código Python reconhecido no conteúdo.")'

        return codigo
    else:
        raise Exception(f"Erro ao gerar código: {response.status_code} - {response.text}")

def salvar_codigo_auto(codigo: str, membro):
    extensao = "py"
    identificador = uuid.uuid4().hex[:8]
    nome_arquivo = f"{membro.id}_{identificador}.{extensao}"

    with open(nome_arquivo, "w", encoding="utf-8") as f:
        f.write(codigo)
    return nome_arquivo

@bot.command(name="codar")
async def codar(ctx, *, prompt: str):
    await ctx.typing()
    try:
        linguagens_nao_python = ["javascript", "js", "html", "css", "c++", "c#", "java", "php", "ruby", "go", "rust"]
        if any(lang in prompt.lower() for lang in linguagens_nao_python):
            await ctx.send("❌ Só aceitamos código Python puro.")
            return

        codigo = await gerar_codigo_groq_python(prompt)

        nome_arquivo = salvar_codigo_auto(codigo, ctx.author)
        await ctx.send(file=discord.File(nome_arquivo))
        os.remove(nome_arquivo)

    except Exception as e:
        await ctx.send(f"❌ Erro ao gerar código Python puro: {e}")


# Evento para saber se está online
@bot.event
async def on_ready():
    print(f"✅ Bot iniciado como {bot.user}")

# Inicia o bot
async def main():
    try:
        await bot.start("MTQwMTI3MjU1Mjk2OTYwNTQ0MQ.GXQGJ9.Qct2L09wZjYbmjr-nQLpmHQW_G3laDF_a1vTXI")
    except discord.errors.GatewayNotFound:
        print("❌ Gateway do Discord não encontrado.")
    except discord.errors.LoginFailure:
        print("❌ Token inválido.")
    except Exception as e:
        print(f"⚠️ Erro inesperado: {e}")

bot.run(main())